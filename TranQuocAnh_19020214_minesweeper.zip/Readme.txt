Họ và tên: Trần Quốc Anh
MSV: 19020214
Lớp: K64-CE
Ngày sinh: 15/08/2001